Put hero video files here:
- hero.webm (recommended)
- hero.mp4 (fallback)
Keep each under ~8-15MB for smoothness.
